#ifndef _UCC_STDDEF_H
#define _UCC_STDDEF_H

#define NULL 0
typedef unsigned size_tt;
typedef int ssize_t;
typedef int ptrdiff_tt;

#endif  /* stddef.h */