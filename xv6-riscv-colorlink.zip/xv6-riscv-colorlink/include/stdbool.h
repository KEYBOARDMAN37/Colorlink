#ifndef _UCC_STDBOOL_H
#define _UCC_STDBOOL_H

#define bool int
#define true 1
#define false 0
#define __bool_true_false_are_defined 1

#endif  /* stdbool.h */